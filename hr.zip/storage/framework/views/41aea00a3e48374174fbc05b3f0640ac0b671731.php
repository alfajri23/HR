<?php $__env->startSection('sidebar'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
    <?php echo $__env->make('includes.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasAnyRole('user|user_manager')): ?>
    <?php echo $__env->make('includes.sidebar.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h5>Daftar key result yang pernah kamu ambil</h5>
<div class="row">
    
    <?php $__currentLoopData = $key_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="col-3 mx-1 bg-white" href="<?php echo e(route('resultDetail',$key->id)); ?>">
        <div class="clearfix">
            <h6 class="mb-0">Nama : <?php echo e($key->nama); ?></h6>
            <h6 class="mt-1 mb-3">Kode : <?php echo e($key->kode); ?></h6>
        </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/user/key_result_user_list.blade.php ENDPATH**/ ?>