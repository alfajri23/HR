<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="widget-bg-transparent">
    
    
    <div class="widget-body bg-white py-3">
        <div class="container d-flex justify-content-between">
            <h5 class="">Daftar divisi</h5>
            <a href="#" data-toggle="modal" data-target="#modalShow"
                                class="ml-4 my-3 btn btn-outline-info">Tambah</a>
        </div>
        
        <div class="container d-flex flex-wrap">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mr-b-30">
                <div class="card">
                    <img class="card-img-top" src="<?php echo e($dt['logo']); ?>" alt="">
                    <div class="card-body">
                        <h4 class="card-title"><?php echo e($dt['nama']); ?></h4>
                        <p class="card-text"></p>
                        <p class="card-text"><?php echo e($dt['deskripsi']); ?></p>
                    </div>
                    <div class="card-action">
                        <a href="javascript:void(0)" onclick="modalShow(<?php echo e($dt['id']); ?>)" class="card-link text-uppercase fw-500"><i class="fas fa-info-circle mr-1"></i>Edit</a>
                        <a href="<?php echo e(route('divisiDelete',$dt['id'])); ?>" class="card-link text-uppercase fw-500"><i class="fas fa-trash mr-1"></i>Delete</a>
                        <a href="<?php echo e(route('divisiDetail',$dt['id'])); ?>" class="card-link text-uppercase fw-500"><i class="fas fa-pencil-alt mr-1"></i>Detail</a>
                    </div>
                </div>
            </div>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- /.widget-body -->
</div>


<!-- /.modal -->
<div class="modal modal-info fade bs-modal-md-primary" id="modalShow" tabindex="-1" role="dialog" aria-labelledby="myMediumModalLabel" aria-hidden="true" style="display: none">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header text-inverse">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 class="modal-title" id="myMediumModalLabel">Medium Modal Heading</h5>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('divisiStore')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <input type="hidden" class="form-control" name="id" id="id" aria-describedby="emailHelp">
                        <label for="exampleInputEmail1" class="form-label">Nama</label>
                        <input type="text" class="form-control" name="nama" id="nama" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Deskripsi</label>
                        <input type="text" class="form-control" name="deskripsi" id="desc">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Manager</label>
                        <select class="form-control" name="id_manager">
                        
                            <option value="3" selected>Feri</option>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($us['id']); ?>" <?php echo e($us['id'] == $dt['id_manager'] ? 'selected' : ''); ?>><?php echo e($us['nama']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Logo</label>
                        <input type="file" class="form-control" name="file" id="logo">
                    </div>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<script type="text/javascript">


	$.ajaxSetup({
	      headers: {
	          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
	          'Authorization': `Bearer <?php echo e(Session::get('token')); ?>`
	      }
	});

    function modalShow(id){
        $.ajax({
			type : 'GET',
			url  : "<?php echo e(route('divisiShow')); ?>",
			data : {
				id : id
			},
			dataType: 'json',
			success : (data)=>{
                $('#modalShow').modal('show');
                $('#id').val(data.data.id);
                $('#nama').val(data.data.nama);
                $('#desc').val(data.data.deskripsi);

                console.log(data);
            }
        });
    }

    

    

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/admin/divisi/divisi.blade.php ENDPATH**/ ?>