<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .bl{
        border-left: 1px solid #e8e8e8
    }

    .photo{
        object-fit: cover;
        width: 100px !important;
        height: 100px !important;
    }
</style>
        <div class="container-fluid d-flex">
            <?php
                $done = 0;
                $progres_tot = 0;
                foreach ($track as $tr){
                    //dd($tr);
                
                    $progres = 0;
                    $target = $tr->target;
                    $bobot = $tr->bobot;
                    $week = explode(",",$tr->week_1);
                    //dd($week);
                    foreach ($track as $tr){
                    $progres_tot += $tr->progres; 
                }

                if(count($track) == 0){
                    $progres_tot = 0;
                }else{
                    $progres_tot = round($progres_tot);
                }
                }

                if(count($track) == 0){
                    $progres_tot = 0;
                }else{
                    $progres_tot = $progres_tot/count($track);
                    $progres_tot = round($progres_tot);
                }
                    

            ?>

            <div class="col-12 col-md-12 widget-holder">
                <div class="widget-bg">
                    <ul class="list-unstyled widget-user-list card-body">
                        <li class="media">
                            <div class="d-flex mr-3">
                                <a class="user--online thumb-xs" style="width:70px;">
                                    <img src="<?php echo e(asset($data->foto)); ?>" class="photo" alt="">
                                </a>
                            </div>
                            <div class="media-body d-flex justify-content-between">        
                                <h5 class="media-heading">
                                    <a href="#"><?php echo e($data->nama); ?></a> 
                                    <small><?php echo e($data->username); ?></small>
                                    <small><?php echo e($data->divisi->nama); ?></small>
                                </h5>
                                <span class="btn-group mr-b-20">
                                    <button type="button" class="btn btn-outline-<?php echo e($jam > 0 ? 'danger' : 'default'); ?> ripple">
                                        <p class="mb-0">
                                            <?php if($jam < 0): ?>
                                                <?php echo e($jam*-1); ?> jam
                                        </p>
                                        <p class="mb-0">Lebih</p>
                                            <?php else: ?>
                                                <?php echo e($jam); ?>

                                        </p>
                                        <p class="mb-0">Hutang jam</p>
                                            <?php endif; ?>

                                    </button>
                                    <button type="button" class="btn btn-outline-default ripple">
                                        <p class="mb-0"><?php echo e(count($track)); ?></p>
                                        <p class="mb-0">Key result</p>
                                    </button>
                                    <button type="button" class="btn btn-outline-default ripple">
                                        <p class="mb-0"><?php echo e(round($progres_tot)); ?>%</p>
                                        <p class="mb-0">Progres</p>
                                    </button>
                                    <button type="button" class="btn btn-outline-default ripple">
                                        <p class="mb-0"><?php echo e($done); ?></p>
                                        <p class="mb-0">Done</p>
                                    </button>
                                </span>
                            </div>
                        </li>
                    </ul>
                    
                    <div class="widget-body clearfix">
                        <div class="tabs mr-t-10">
                            <ul class="nav nav-tabs">
                                <li class="nav-item"><a href="#home-tab-bordered-1" class="nav-link active" data-toggle="tab" aria-expanded="true">Activity</a>
                                </li>
                                <li class="nav-item"><a href="#okr-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">OKR</a>
                                </li>
                                <li class="nav-item"><a href="#ganti-jam-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">Ganti jam</a>
                                </li>
                                <li class="nav-item"><a href="#izin-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">Izin</a>
                                </li>
                                <li class="nav-item"><a href="#lembur-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">Lembur</a>
                                </li>
                                <li class="nav-item"><a href="#cuti-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">Cuti</a>
                                </li>
                                <li class="nav-item"><a href="#absensi-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">Absensi</a>
                                </li>       
                                <li class="nav-item"><a href="#profile-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">Profile</a>
                                </li>
                                <li class="nav-item"><a href="#edit-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">Edit</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <!-- Progress -->
                                <div class="tab-pane active" id="home-tab-bordered-1">
                                    <div class="container bg-white p-3">
                                        <h5>OKR Berjalan</h5>
                                        <?php $__empty_1 = true; $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e => $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <h4><?php echo e($e); ?></h4>
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 2px">No</th>
                                                    <th>Kode</th>
                                                    <th>Key result</th>
                                                    <th>Bobot</th>
                                                    <th>Target</th>
                                                    <th>Start</th>
                                                    <th>Pekan 1</th>
                                                    <th>Pekan 2</th>
                                                    <th>Pekan 3</th>
                                                    <th>Pekan 4</th>
                                                    <th>Pekan 5</th>
                                                    <th>Progres</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $tot_progres = 0;
                                                ?>
                                                <?php $__currentLoopData = $track; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($tr->kode_key); ?></td>
                                                    <td><?php echo e($tr->keyResult->nama); ?></td>
                                                    <td><?php echo e($tr->bobot); ?></td>
                                                    <td><?php echo e($tr->target); ?></td>
                                                    <td><?php echo e($tr->start); ?></td>
                                                    <?php
                                                        if($tr->week_1 != null){
                                                            $week = explode(",",$tr->week_1);
                                                        }else {
                                                            $week = [];
                                                        }  
                                                    ?>
                                                    
                                                    <?php for($i = 0; $i < 5; $i++): ?>
                                                        <?php if(empty($week[$i])): ?>
                                                        <td>
                                                            
                                                        </td>
                                                        <?php else: ?>
                                                        <td><?php echo e($week[$i]); ?></td>
                                                        <?php endif; ?>
                                                        
                                                    <?php endfor; ?>
                                                    <td>
                                                        <p class="my-0"><?php echo e($tr->progres); ?>%</p>
                                                        <div class="progress" data-toggle="tooltip" title="<?php echo e($tr->progres); ?>%">
                                                            <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tr->progres); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tr->progres); ?>%"><span class="sr-only"><?php echo e($tr->progres); ?>%</span>
                                                            </div>
                                                        </div>
                                                        </td>
                                                    
                                                </tr>
                                                <?php
                                                    
                                                    $tot_progres += $tr->progres;
                                                ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td colspan="11" class="text-center">Total progres</td>
                                                    <td>
                                                        <p class="my-0"><?php echo e($tot_progres); ?>%</p>
                                                        <div class="progress" data-toggle="tooltip" title="<?php echo e($tot_progres); ?>%">
                                                            <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tot_progres); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tot_progres); ?>%"><span class="sr-only"><?php echo e($tot_progres); ?>%</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td colspan="1"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>    

                                        <?php endif; ?>

                                        <?php if(!empty($multi)): ?>
                                            <h4>Total</h4>
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th style="width: 2px">No</th>
                                                        <th>Kode</th>
                                                        <th style="width: 300px;">Key result</th>
                                                        <th>Bobot</th>
                                                        <th>Target</th>
                                                        <th>Start</th>
                                                        <th>Pekan 1</th>
                                                        <th>Pekan 2</th>
                                                        <th>Pekan 3</th>
                                                        <th>Pekan 4</th>
                                                        <th>Pekan 5</th>
                                                        <th>Progres</th>
                                                        <th>Aksi</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        $tot_progres = 0;
                                                    ?>
                                                    <?php $__currentLoopData = $multi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($tr['kode_key']); ?></td>
                                                        <td><?php echo e($tr['nama']); ?></td>
                                                        <td>10%</td>
                                                        <td>100%</td>
                                                        <td>0</td>
                                                        <?php for($i = 0; $i < count($tr['data_pekan']); $i++): ?>
                                                            <?php if(empty($tr['data_pekan'][$i])): ?>
                                                            <td>
                                                                
                                                            </td>
                                                            <?php else: ?>
                                                            <td><?php echo e(number_format($tr['data_pekan'][$i])); ?></td>
                                                            <?php endif; ?>
                                                            
                                                        <?php endfor; ?>
                                                        <td>
                                                            <p class="my-0"><?php echo e($tr['progres']); ?>%</p>
                                                            <div class="progress" data-toggle="tooltip" title="<?php echo e($tr['progres']); ?>%">
                                                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tr['progres']); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tr['progres']); ?>%"><span class="sr-only"><?php echo e($tr['progres']); ?>%</span>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <?php
                                                    
                                                            $tot_progres += $tr['progres'];
                                                        ?>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td colspan="11" class="text-center">Total progres</td>
                                                        <td>
                                                            <p class="my-0"><?php echo e($tot_progres); ?>%</p>
                                                            <div class="progress" data-toggle="tooltip" title="<?php echo e($tot_progres); ?>%">
                                                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tot_progres); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tot_progres); ?>%"><span class="sr-only"><?php echo e($tot_progres); ?>%</span>
                                                                </div>
                                                            </div></td>
                                                        <td colspan="2"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        <?php endif; ?>

                                    </div>
                                    <div class="container bg-light p-3">
                                        <h5>OKR Tracking</h5>
                                        <canvas id="myChart"></canvas>
                                    </div>
                                </div>
                                <!-- End Progress -->

                                
                                <div class="tab-pane" id="okr-tab-bordered-1">
                                    <h4>OKR</h4>
                                    <div class="row">
                                        <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="col-sm-3 mr-b-20" href="<?php echo e(route('trackUser',['id' =>$data->id, 'm' => $loop->iteration])); ?>">
                                            
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title"><?php echo e($bln); ?></h5>
                                                    </div>
                                                </div>
                                            
                                        </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                          
                                <!-- Ganti jam -->
                                <div class="tab-pane" id="ganti-jam-tab-bordered-1">
                                    <div class="container">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 3%">No</th>
                                                    <th style="width: 11%">Tanggal</th>
                                                    <th style="width: 5%">Jam</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $jams = 0;
                                                ?>
                                                <?php $__empty_1 = true; $__currentLoopData = $ganti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php
                                                        $jams = $jams + $iz->jam;
                                                    ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($iz->hari); ?></td>
                                                        <td><?php echo e($iz->jam); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="8" class="text-center"> tidak ada data</td>
                                                </tr>
                                                    
                                                <?php endif; ?>
                                                <tr>
                                                    <td colspan="2" class="text-center">Hutang jam</td>
                                                    <td><?php echo e($jams); ?></td>
                    
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <!-- Ijin -->
                                <div class="tab-pane" id="izin-tab-bordered-1">
                                    <div class="row">
                                        <div class="col-9">
                                            <h5>Daftar izin <?php echo e($data->nama); ?> bulan ini</h5>
                                        </div>
                                        <div class="col-3">
                                            <h5>Total hutang izin : <?php echo e($ijin); ?> jam</h5>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="row">
                                        <?php $__empty_1 = true; $__currentLoopData = $izin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-sm-4 mr-b-20">
                                            <div class="card bg-light">
                                                <div class="card-body">
                                                    <div class="d-flex justify-content-between">
                                                        <h5 class="card-title"><?php echo e($iz->tipe); ?></h5>
                                                        
                                                        <span>
                                                            <?php if($iz->ganti_jam == 1): ?>
                                                            <h6 class="card-title mb-0">Hutang <?php echo e($iz->jam); ?> jam</h6>
                                                            <?php endif; ?>
                                                            <?php if($iz->dinas == 1): ?>
                                                            <i class="fas fa-ad fa-lg mr-1" style="color: gold"></i><p class="my-0 d-inline" style="color: rgb(134, 120, 40)">Administratif</p>
                                                            <?php endif; ?>
                                                        </span>
                                                            
                                                        
                                                        
                                                    </div>
                                                    <p class="card-text text-dark"><?php echo e($iz->alasan); ?></p>
                                                    <p class="card-text text-dark">
                                                        <?php echo e($iz->tanggal_mulai); ?>


                                                        <?php if(empty($iz->tanggal_akhir)): ?>
                                                            
                                                        <?php else: ?>
                                                            sampai <?php echo e($iz->tanggal_akhir); ?><br>
                                                            <?php echo e($iz->hari); ?> hari   

                                                        <?php endif; ?>
                                                    
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <h6 class="ml-4">tidak ada catatan izin</h6>
                                        <?php endif; ?>
                                        
                                    </div>
                                </div>
   
                                <!-- Lembur -->
                                <div class="tab-pane" id="lembur-tab-bordered-1">
                                    <div class="container">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 3%">No</th>
                                                    <th style="width: 11%">Tanggal</th>
                                                    <th>Alasan</th>
                                                    <th style="width: 5%">Jam</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $jams = 0;
                                                ?>
                                                <?php $__empty_1 = true; $__currentLoopData = $lembur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php
                                                        $jams = $jams + $iz->jam;
                                                    ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($iz->hari); ?></td>
                                                        <td><?php echo e($iz->alasan); ?></td>
                                                        <td><?php echo e($iz->jam); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="8" class="text-center"> tidak ada data</td>
                                                </tr>
                                                    
                                                <?php endif; ?>
                                                <tr>
                                                    <td colspan="3" class="text-center">Total jam</td>
                                                    <td ><?php echo e($jams); ?></td>
                    
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <!-- Cuti -->
                                <div class="tab-pane" id="cuti-tab-bordered-1">
                                    <div class="col-6">
                                        <h5>Jatah cuti : <?php echo e($data->cuti); ?> </h5>
                                    </div>
                                    
                                    <div class="row">
                                        <?php $__empty_1 = true; $__currentLoopData = $cuti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-sm-4 mr-b-20">
                                            <div class="card bg-light">
                                                <div class="card-body">
                                                    <div class="d-flex justify-content-between">
                                                        <h5 class="card-title"><?php echo e($iz->tipe); ?></h5>
                                                    </div>
                                                    <p class="card-text text-dark"><?php echo e($iz->alasan); ?></p>
                                                    <p class="card-text text-dark">
                                                        <?php echo e($iz->tanggal_mulai); ?>


                                                        <?php if(empty($iz->tanggal_akhir)): ?>
                                                            
                                                        <?php else: ?>
                                                            sampai <?php echo e($iz->tanggal_akhir); ?><br>
                                                            <?php echo e($iz->hari); ?> hari   

                                                        <?php endif; ?>
                                                    
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            tidak ada catatan cuti
                                        <?php endif; ?>
                                        
                                    </div>
                                </div>

                                
                                <div class="tab-pane" id="absensi-tab-bordered-1">
                                    <div class="container bg-white p-3">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10%">Bulan</th>
                                                    <th>Jam masuk</th>
                                                    <th>Total jam</th>
                                                    <th>Max Jam</th>
                                                    <th>Hasil</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $bulan = 1;
                                                ?>
                                                <?php $__empty_1 = true; $__currentLoopData = $absen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php
                                                        $bulan++;
                                                    ?>
                                                    
                                                <tr>
                                                    <td><?php echo e($tr->bulan); ?></td>
                                                    <td><?php echo e($tr->jam_masuk); ?></td>
                                                    <td><?php echo e($tr->total_jam); ?></td>  
                                                    <td></td>   
                                                    <td><?php echo e($tr->hasil); ?></td>                                                    
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    
                                                <?php endif; ?>
                                                <tr>
                                                    <form action="<?php echo e(route('absenStore')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <td>
                                                        <input class="form-control" name="id_user" value="<?php echo e($data->id); ?>" type="hidden">
                                                        <input class="form-control" name="bulan" value="<?php echo e($bulan); ?>" type="hidden">
                                                        <?php echo e($bulan); ?>

                                                    </td>
                                                    <td>
                                                        <input class="form-control" name="jam" type="time" >
                                                    </td>
                                                    <td>
                                                        <input class="form-control" name="tot" type="number" >
                                                    </td>
                                                    <td>
                                                        <?php if(!empty(session('jam_max'))): ?>
                                                            <input class="form-control" value="<?php echo e(session('jam_max')); ?>" name="max" type="number" readonly>
                                                        <?php else: ?>
                                                        <input class="form-control" name="max" type="number" >
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <button type="submit" class="btn btn-primary btn-sm">Update</button>
                                                    </td>
                                                    </form>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            
                                <!-- Detail -->
                                <div class="tab-pane" id="profile-tab-bordered-1">
                                    <div class="contact-details-profile pd-lr-30">
                                        <h4>Profile</h4>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Nama</h6>
                                                <p class="mr-t-0"><?php echo e($data->nama); ?></p>

                                            </div>
                                            
                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Username</h6>
                                                <p class="mr-t-0"><?php echo e($data->username); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Jenis kelamin</h6>
                                                <p class="mr-t-0"><?php echo e($data->jenkel); ?></p>
                                            </div>
                                            
                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Alamat</h6>
                                                <p class="mr-t-0"><?php echo e($data->alamat); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Alamat KTP</h6>
                                                <p class="mr-t-0"><?php echo e($data->alamat_ktp); ?></p>
                                            </div>
                                            
                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Telepon</h6>
                                                <p class="mr-t-0"><?php echo e($data->telepon); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Telepon WA</h6>
                                                <p class="mr-t-0"><?php echo e($data->telepon_wa); ?></p>
                                            </div>

                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Tempat lahir</h6>
                                                <p class="mr-t-0"><?php echo e($data->tmpt_lahir); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Tanggal lahir</h6>
                                                <p class="mr-t-0"><?php echo e($data->tgl_lahir); ?></p>
                                            </div>

                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Usia</h6>
                                                <p class="mr-t-0"><?php echo e($data->usia); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">status_keluarga</h6>
                                                <p class="mr-t-0">
                                                    <?php switch($data->status_keluarga):
                                                        case (1): ?>
                                                            Menikah
                                                            <?php break; ?>
                                                        <?php case (2): ?>
                                                            Belum menikah
                                                            <?php break; ?>
                                                        
                                                        <?php default: ?>
                                                    <?php endswitch; ?>
                                            </div>
                                        
                                        <hr class="mr-tb-50">

                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Sekolah</h6>
                                                <p class="mr-t-0"><?php echo e($data->sekolah); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Pendidikan</h6>
                                                <p class="mr-t-0"><?php echo e($data->pendidikan); ?></p>
                                            </div>

                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Jurusan</h6>
                                                <p class="mr-t-0"><?php echo e($data->jurusan); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Rekening</h6>
                                                <p class="mr-t-0"><?php echo e($data->rekening); ?></p>
                                            </div>

                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Npwp</h6>
                                                <p class="mr-t-0"><?php echo e($data->npwp); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Bpjs tenaga kerja</h6>
                                                <p class="mr-t-0"><?php echo e($data->bpjs_tk); ?></p>
                                            </div>

                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Bpjs kesehatan</h6>
                                                <p class="mr-t-0"><?php echo e($data->bpjs_kes); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Cuti</h6>
                                                <p class="mr-t-0"><?php echo e($data->cuti); ?></p>
                                            </div>

                                        </div>
                                        
                                        <hr class="mr-tb-50">

                                        <h4>Informasi</h4>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Pangkat</h6>
                                                <p class="mr-t-0">
                                                    <?php switch($data->pangkat):
                                                        case (1): ?>
                                                            Direktur
                                                            <?php break; ?>
                                                        <?php case (2): ?>
                                                            Manager
                                                            <?php break; ?>
                                                        <?php case (3): ?>
                                                            Supervisor
                                                            <?php break; ?>
                                                        <?php case (4): ?>
                                                            Officer
                                                            <?php break; ?>
                                                    
                                                        <?php default: ?>
                                                        
                                                    <?php endswitch; ?>
                                                    
                                                </p>
                                            </div>
                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Level</h6>
                                                <p class="mr-t-0"><?php echo e($data->level); ?>

                                                    
                                                </p>
                                            </div>
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Divisi</h6>
                                                <p class="mr-t-0">
                                                    <?php switch($data->id_divisi):
                                                        case (1): ?>
                                                            HR
                                                            <?php break; ?>
                                                        <?php case (2): ?>
                                                            Budimark
                                                            <?php break; ?>
                                                        <?php case (3): ?>
                                                            MySch
                                                            <?php break; ?>
                                                        <?php case (4): ?>
                                                            Makin mahir
                                                            <?php break; ?>
                                                        <?php case (5): ?>
                                                            Dev
                                                            <?php break; ?>
                                                        <?php default: ?>
                                                    <?php endswitch; ?>
                                                
                                                    
                                                </p>
                                            </div>
                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Jabatan</h6>
                                                <p class="mr-t-0"><?php echo e($data->jabatan); ?></p>
                                            </div>
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Status kerja</h6>
                                                <p class="mr-t-0">
                                                    <?php switch($data->status_kerja):
                                                        case (1): ?>
                                                            Karyawan tetap
                                                            <?php break; ?>
                                                        <?php case (2): ?>
                                                            Karyawan tidak tetap
                                                            <?php break; ?>
                                                        <?php case (3): ?>
                                                            Karyawan kontrak
                                                            <?php break; ?>
                                                        <?php case (4): ?>
                                                            Karyawan freelancer
                                                            <?php break; ?>
                                                        <?php case (5): ?>
                                                            Training
                                                            <?php break; ?>
                                                        <?php case (6): ?>
                                                            Magang
                                                            <?php break; ?>
                                                        <?php default: ?>
                                                    <?php endswitch; ?>
                                                </p>
                                            </div>
                                            <div class="col-md-6 bl">
                                                <h6 class="text-muted text-uppercase">Habis kontrak</h6>
                                                <p class="mr-t-0"><?php echo e($data->habis_kontrak); ?></p>
                                            </div>
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Reminder habis kontrak</h6>
                                                <p class="mr-t-0"><?php echo e($data->reminder_habis_kontrak); ?></p>
                                            </div>
                                        </div>
                                        <hr class="border-0 mr-tb-50">
                                    </div>
                                </div>
                                <!-- End Detail -->

                                <!-- Edit -->
                                <div class="tab-pane" id="edit-tab-bordered-1">
                                    <form class="form-material pt-3" action="<?php echo e(route('karyawanUpdate')); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="media align-items-center p-3 mb-4 bg-light-grey">
                                            <div class="d-flex mr-4 w-25 justify-content-end">
                                                <figure class="mb-0 thumb-md">
                                                    <img src="<?php echo e(asset($data->foto)); ?>" class="img-thumbnail">
                                                </figure>
                                            </div>
                                            <!-- /.d-flex -->
                                            <div class="media-body w-75">
                                                <div class="form-group">
                                                    <input type="file" class="form-control" name="file" id="logo">
                                                    <label for="exampleInputFile">File input</label>
                                                </div>
                                            </div>
                                            <!-- /.media-body -->
                                        </div>
                                        <!-- /.media -->
                                        <div class="row">
                                            <div class="col-md-9">
                                                <div class="form-group">
                                                    <input type="hidden" class="form-control" value="<?php echo e($data->id); ?>" name="id" id="id" aria-describedby="emailHelp">
                                                    <input type="text" class="form-control" value="<?php echo e($data->nama); ?>" name="nama" id="nama" aria-describedby="emailHelp">
                                                    <label>Nama</label>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <input type="number" class="form-control" value="<?php echo e($data->cuti); ?>" name="cuti" id="cuti" aria-describedby="emailHelp">
                                                    <label>Cuti</label>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->username); ?>" name="username" id="usernama" aria-describedby="emailHelp">
                                                    <label>Username</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="number" class="form-control" value="<?php echo e($data->nik); ?>" name="nik" id="usernama" aria-describedby="emailHelp">
                                                    <label>NIK</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->alamat); ?>" name="alamat" id="usernama" aria-describedby="emailHelp">
                                                    <label>Alamat</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->alamat_ktp); ?>" name="alamat_ktp" id="usernama" aria-describedby="emailHelp">
                                                    <label>Alamat KTP</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->tmpt_lahir); ?>" name="tmpt_lahir" id="email">
                                                    <label for="example-email">Tempat lahir</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input onfocus="(this.type='date')" type="text" name="tgl_lahir" value="<?php echo e($data->tgl_lahir); ?>" class="form-control form-control-line">
                                                    <label>Tanggal lahir</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" placeholder="BCA 123 456 7890" name="rekening" value="<?php echo e($data->rekening); ?>" class="form-control form-control-line">
                                                    <label>Rekening</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="email" class="form-control" value="<?php echo e($data->email); ?>" name="email" id="email">
                                                    <label for="example-email">Email</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="number" placeholder="123 456 7890" name="telepon_wa" value="<?php echo e($data->telepon_wa); ?>" class="form-control form-control-line">
                                                    <label>Telepon WA</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="number" placeholder="123 456 7890" name="telepon" value="<?php echo e($data->telepon); ?>" class="form-control form-control-line">
                                                    <label>Telepon</label>
                                                </div>
                                            </div>
                                        </div>


                                        
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->pendidikan); ?>" name="pendidikan" id="email">
                                                    <label for="example-email">Pendidikan</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" name="sekolah" value="<?php echo e($data->sekolah); ?>" class="form-control form-control-line">
                                                    <label>Sekolah</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->jurusan); ?>" name="jurusan" id="email">
                                                    <label for="example-email">Jurusan</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <select id="keluarga" class="form-control" value="<?php echo e($data->status_keluarga); ?>" name="status_keluarga">
                                                        <option value="<?php echo e($data->status_keluarga); ?>">Pilih</option>
                                                        <option value="1">Menikah</option>
                                                        <option value="2">Belum menikah</option>
                                                    </select>
                                                    <label for="keluarga">Status keluarga</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                <select id="jk" class="form-control" value="<?php echo e($data->jenkel); ?>" name="jenkel">
                                                    <option value="<?php echo e($data->jenkel); ?>">Pilih</option>
                                                    <option value="1">Laki-laki</option>
                                                    <option value="2">Perempuan</option>
                                                </select>
                                                <label for="jk">Jenis kelamin</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="number" class="form-control" value="<?php echo e($data->usia); ?>" name="usia" id="email">
                                                    <label for="example-email">Usia</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->npwp); ?>" name="npwp" id="email">
                                                    <label for="example-email">NPWP</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" name="bpjs_kes" value="<?php echo e($data->bpjs_kes); ?>" class="form-control form-control-line">
                                                    <label>BPJS Kes</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->bpjs_tk); ?>" name="bpjs_tk" id="email">
                                                    <label for="example-email">BPJS TK</label>
                                                </div>
                                            </div>
                                        </div>

                                
                                        <div class="form-group">
                                            <input type="text" class="form-control" value="<?php echo e($data->jabatan); ?>" name="jabatan" id="usernama" aria-describedby="emailHelp">
                                            <label>Jabatan</label>
                                        </div>
                                        
                                        <div class="row">  
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <select class="form-control" name="status_kerja" value="<?php echo e($data->status_kerja); ?>">
                                                        <option value="<?php echo e($data->status_kerja); ?>">Pilih</option>
                                                        <option value="1">Karyawan tetap</option>
                                                        <option value="2">Karyawan tidak tetap</option>
                                                        <option value="3">Karyawan kontrak</option>
                                                        <option value="4">Karyawan freelancer</option>
                                                        <option value="5">Training</option>
                                                        <option value="6">Magang</option>
                                                    </select>
                                                    <label for="l38">Status kerja</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <select class="form-control" name="pangkat" value="<?php echo e($data->pangkat); ?>">
                                                        <option value="<?php echo e($data->pangkat); ?>">Pilih</option>
                                                        <option value="1">Direktur</option>
                                                        <option value="2">Manager</option>
                                                        <option value="3">Supervisor</option>
                                                        <option value="4">Officer</option>
                                                    </select>
                                                    <label for="l38">Pangkat</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input onfocus="(this.type='date')" type="text" class="form-control" value="<?php echo e($data->tgl_masuk_grup); ?>" name="tgl_masuk_grup" id="email">
                                                    <label for="example-email">Tanggal masuk grup</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input onfocus="(this.type='date')" type="text" name="tgl_masuk" value="<?php echo e($data->tgl_masuk); ?>" class="form-control form-control-line">
                                                    <label>Tanggal masuk</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input onfocus="(this.type='date')" type="text" class="form-control" value="<?php echo e($data->habis_kontrak); ?>" name="habis_kontrak" id="email">
                                                    <label for="example-email">Habis kontrak</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input onfocus="(this.type='date')" type="text" name="reminder_habis_kontrak" value="<?php echo e($data->remider_habis_kontrak); ?>" class="form-control">
                                                    <label>Reminder habis kontrak</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <select class="form-control" name="id_divisi" id="l13">
                                                        <option value="<?php echo e($data->id_divisi); ?>">Pilih</option>
                                                        <?php $__currentLoopData = $divisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($us['id']); ?>"><?php echo e($us['nama']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <label for="l38">Divisi</label>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <select class="form-control" name="level" id="l13">
                                                        <option value="<?php echo e($data->level); ?>">Pilih</option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                    </select>
                                                    <label for="l38">Level</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <select class="form-control" value="<?php echo e($data->edukasi_pekanan); ?>" name="edukasi_pekanan">
                                                        <option value="<?php echo e($data->edukasi_pekanan); ?>">Pilih</option>
                                                        <option value="1">Aktif</option>
                                                        <option value="2">Tidak aktif</option>
                                                    </select>
                                                    <label for="l38">Edukasi pekanan</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <button class="btn btn-success ripple">Update Profile</button>
                                        </div>
                                    </form>
                                </div>
                                <!-- End Edit -->
                            </div>
                            <!-- End tab-content -->
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            <!-- End col-12 -->
            
        </div>
        


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    let datas = "<?php echo e($track_tahun); ?>";

    const labels = [
        'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    ];

    const data = {
        labels: labels,
        datasets: [{
            label: 'Progres',
            backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 132)',
            data: datas.split(","),
        }]
    };

    const config = {
        type: 'line',
        data: data,
        options: {
            scales: {
                y: {
                    suggestedMin: 0,
                    suggestedMax: 100
                },
            }
        }
    };

    const myChart = new Chart(
        document.getElementById('myChart'),
        config
    );



</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/admin/karyawan/karyawan-detail.blade.php ENDPATH**/ ?>