<?php $__env->startSection('sidebar'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('user|user_manager')): ?>
        <?php echo $__env->make('includes.sidebar.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <?php echo $__env->make('includes.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    p{
        margin: 0;
    }
</style>
<div class="container-fluid bg-white p-5">
    <?php if($status == 1): ?>
        <div class="row">
            <div class="col-2">
                <p>Divisi</p>
                <p>Nama</p>
                <p class="mb-2">Jabatan</p>
            </div>
            <div class="col-sm-8 col-6">
                <p>: <?php echo e($data->divisi->nama); ?></p>
                <p>: <?php echo e($data->nama); ?></p>
                <p class="mb-2">: <?php echo e($data->jabatan); ?></p>
            </div>
            <div class="col-2">
                <h4 class="mt-0"><?php echo e($bulan); ?></h4>
            </div>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e => $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <h4><?php echo e($e); ?></h4>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width: 2px">No</th>
                        <th>Kode</th>
                        <th>Key result</th>
                        <th>Bobot</th>
                        <th>Target</th>
                        <th>Start</th>
                        <th>Pekan 1</th>
                        <th>Pekan 2</th>
                        <th>Pekan 3</th>
                        <th>Pekan 4</th>
                        <th>Pekan 5</th>
                        <th>Total</th>
                        <th>Progres</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $tot_progres = 0;
                        $tot_bobot = 0;
                    ?>
                    <?php $__empty_2 = true; $__currentLoopData = $track; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($tr->kode_key); ?></td>
                        <td><?php echo e($tr->keyResult->nama); ?></td>
                        <td class="text-center"><?php echo e($tr->bobot); ?></td>
                        <td class="text-center"><?php echo e(number_format($tr->target)); ?></td>
                        <td class="text-center"><?php echo e($tr->start); ?></td>
                        <?php
                            if($tr->week_1 != null){
                                $week = explode(",",$tr->week_1);
                            }else {
                                $week = [];
                            }  
                        ?>
                        <form action="<?php echo e(route('trackUpdate')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                        <?php for($i = 0; $i < 5; $i++): ?>
                            <?php if(empty($week[$i])): ?>
                            <td>
                                <input class="form-control" name="id" value="<?php echo e($tr->id); ?>" type="hidden">
                                <input class="form-control" name="week_no[]" value="<?php echo e($i); ?>" type="hidden">
                                <input type="text" class="form-control" name="week_val[]" style="
                                    width: 100px;
                                    padding: 8px 2px;
                                ">
                            </td>
                            <?php else: ?>
                            <td class="text-center"><?php echo e(number_format($week[$i])); ?></td>
                            <?php endif; ?>
                            
                        <?php endfor; ?>
                        <td>
                            <?php if(empty($tr->total)): ?>
                            <input type="number" class="form-control" name="total" style="
                                    width: 100px;
                                    padding: 8px 2px;
                            ">
                            <small id="emailHelp" class="form-text text-muted">Isi terakhir</small>
                            <?php else: ?>
                            <input type="number" class="form-control" name="total" value="<?php echo e($tr->total); ?>" readonly style="
                                    width: 100px;
                                    padding: 8px 2px;
                            ">
                            <?php endif; ?>
                        </td>
                        <td>
                            <p class="my-0"><?php echo e($tr->progres); ?>%</p>
                            
                        </td>
                        <td>
                            <button type="submit" class="btn btn-primary btn-sm">Update</button>
                        </td>
                        </form>
                    </tr>
                    <?php                    
                        $tot_progres += $tr->progres;
                        $tot_bobot += $tr->bobot;
                    ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>

                    <?php endif; ?>
                    <tr>
                        <td colspan="3" class="text-center">Bobot</td>
                        <td colspan="1"><?php echo e($tot_bobot); ?></td>
                        <td colspan="8" class="text-center">Total progres</td>
                        <td colspan="1">
                            <p class="my-0"><?php echo e($tot_progres); ?>%</p>
                            <div class="progress" data-toggle="tooltip" title="<?php echo e($tot_progres); ?>%">
                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tot_progres); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tot_progres); ?>%"><span class="sr-only"><?php echo e($tot_progres); ?>%</span>
                                </div>
                            </div>
                        </td>
                        <td colspan="1"></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>

        <?php if(!empty($multi)): ?>
            <h4>Total</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width: 2px">No</th>
                        <th>Kode</th>
                        <th style="width: 300px;">Key result</th>
                        <th>Pekan 1</th>
                        <th>Pekan 2</th>
                        <th>Pekan 3</th>
                        <th>Pekan 4</th>
                        <th>Pekan 5</th>
                        <th>Progres</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $tot_progres = 0;
                    ?>
                    <?php $__currentLoopData = $multi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($tr['kode_key']); ?></td>
                        <td><?php echo e($tr['nama']); ?></td>
                        <?php for($i = 0; $i < count($tr['data_pekan']); $i++): ?>
                            <?php if(empty($tr['data_pekan'][$i])): ?>
                            <td>
                                
                            </td>
                            <?php else: ?>
                            <td class="text-center"><?php echo e(number_format($tr['data_pekan'][$i])); ?></td>
                            <?php endif; ?>
                            
                        <?php endfor; ?>
                        <td>
                            <p class="my-0"><?php echo e($tr['progres']); ?>%</p>
                            <div class="progress" data-toggle="tooltip" title="<?php echo e($tr['progres']); ?>%">
                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tr['progres']); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tr['progres']); ?>%"><span class="sr-only"><?php echo e($tr['progres']); ?>%</span>
                                </div>
                            </div>
                        </td>
                        <?php
                    
                            $tot_progres += $tr['progres'];
                        ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="8" class="text-center">Total progres</td>
                        <td colspan="1">
                            <p class="my-0"><?php echo e($tot_progres); ?>%</p>
                            <div class="progress" data-toggle="tooltip" title="<?php echo e($tot_progres); ?>%">
                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tot_progres); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tot_progres); ?>%"><span class="sr-only"><?php echo e($tot_progres); ?>%</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>


    <?php else: ?>
        <div class="row flex-column align-items-center">
            <h4>Mohon input evaluasi ibadah Anda dulu</h4>
            <a href="<?php echo e(route('ibadahInput')); ?>" class="btn btn-primary btn-sm">Input ibadah</a>
        </div>
        
    <?php endif; ?>
    
</div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/user/okr_input.blade.php ENDPATH**/ ?>