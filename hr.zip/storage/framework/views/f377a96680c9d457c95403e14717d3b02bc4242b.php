<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.sidebar.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container bg-white p-3">

    <h4>Histori track OKR</h4>
    <div class="col-12">
        <canvas id="myChart"></canvas>
      </div>
       

</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    let datas = "<?php echo e($track_tahun); ?>";

    const labels = [
        'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    ];

    const data = {
        labels: labels,
        datasets: [{
            label: 'Progres',
            backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 132)',
            data: datas.split(","),
        }]
    };

    const config = {
        type: 'line',
        data: data,
        options: {
            scales: {
                y: {
                    suggestedMin: 0,
                    suggestedMax: 100
                },
            }
        }
    };

    const myChart = new Chart(
        document.getElementById('myChart'),
        config
    );



</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/user/okr_histori.blade.php ENDPATH**/ ?>