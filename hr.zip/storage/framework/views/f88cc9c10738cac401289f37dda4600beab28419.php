<?php $__env->startSection('sidebar'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
    <?php echo $__env->make('includes.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('user|user_manager')): ?>
    <?php echo $__env->make('includes.sidebar.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container bg-white p-3">
        
        
        <?php if($status == 1): ?>
            <h4 class="text-center mb-4">Evaluasi amal harian pekan <?php echo e($pekan); ?></h4>
            <a href="<?php echo e(route('ibadahHistory')); ?>" class="btn btn-primary btn-input btn-sm mb-2">Riwayat</a>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th style="width: 5%">Ya</th>
                        <th style="width: 5%">Tidak</th>
                    </tr>
                </thead>
                <form action="<?php echo e(route('ibadahInputStore')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dt->nama); ?></td>
                        <td>
                            <div class="clearfix">
                            <input class="form-check-input ml-0" type="radio" name="gridRadios-<?php echo e($loop->iteration); ?>" id="gridRadios-<?php echo e($loop->iteration); ?>" value="1">
                            </div>
                        </td>
                        <td>
                            <div>
                            <input class="form-check-input ml-0" type="radio" name="gridRadios-<?php echo e($loop->iteration); ?>" id="gridRadios-<?php echo e($loop->iteration); ?>" value="0">
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
                
            </table>
            <span class="clearfix">
                <button type="submit" class="btn btn-success btn-md float-right">Kirim</button>
            </span>
                
            </form>
        <?php else: ?>
        <div class="row flex-column align-items-center">
            <h4>Input evaluasi amal harian hanya</h4>
            <h4>dibuka hari jumat dan sabtu</h4>
        </div>
            
        <?php endif; ?>
        

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/user/ibadah_input.blade.php ENDPATH**/ ?>