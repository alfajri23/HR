<?php $__env->startSection('sidebar'); ?>
<?php if(auth()->check() && auth()->user()->hasAnyRole('user|user_manager')): ?>
<?php echo $__env->make('includes.sidebar.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<?php echo $__env->make('includes.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 col-md-4 widget-holder">
        <div class="widget-bg">
            <div class="widget-body clearfix">
                <div class="contact-info">
                    <header class="text-center">
                        <div class="text-center">
                            <img class="rounded-circle img-thumbnail" src="<?php echo e(asset($divisi->logo)); ?>" alt="">   
                        </div>
                        <h4 class="mt-1"><a href="#"><?php echo e($divisi->nama); ?></a> <span class="badge text-uppercase badge-warning align-middle">Pro</span></h4>
                        
                    </header>
                    <section class="padded-reverse">
                        <h5>Detail <small class="float-right">Divisi: <strong><?php echo e($divisi->nama); ?></strong></small></h5>
                        <div class="row text-center">
                            <div class="col-12"><span><?php echo e(count($divisi->objectives)); ?></span>
                                <br><small>Objective</small>
                            </div>
                            
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-8 widget-holder widget-full-height">
        <div class="widget-bg">
            <div class="widget-body clearfix">
                <h5 class="box-title">Ranking OKR Divisi <?php echo e($divisi->nama); ?></h5>
                <ul class="list-unstyled widget-user-list mb-0">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="media d-flex align-items-center"> 
                        <h5 class="mr-2 my-0"><?php echo e($loop->iteration); ?></h5>
                        <div class="d-flex mr-3">
                            <a href="#" class="user--online thumb-xs">
                                <img src="<?php echo e(asset($dt['user']->foto)); ?>" class="rounded-circle" alt="">
                            </a>
                        </div>
                        <div class="media-body d-flex justify-content-between">
                            <h5 class="media-heading">
                                <?php if(auth()->check() && auth()->user()->hasAnyRole('admin|user_manager')): ?>
                                <a href="<?php echo e(route('karyawanDetail',$dt['user']->id)); ?>"><?php echo e($dt['user']->nama); ?></a> 
                                <?php endif; ?>
                                <?php if(auth()->check() && auth()->user()->hasAnyRole('user')): ?>
                                <a><?php echo e($dt['user']->nama); ?></a> 
                                <?php endif; ?>
                                <small><?php echo e($dt['user']->divisi->nama); ?></small>
                            </h5>
                            <div class="clearfix" style="width: 80%">
                                <div class="progress progress-md">
                                    <div class="progress-bar bg-<?php echo e(($dt['progres'] >= 70) ? "success" : (($dt['progres'] < 70 && $dt['progres'] >= 40)  ? "warning" : "danger")); ?>" style="width: <?php echo e($dt['progres']); ?>%" role="progressbar"><?php echo e($dt['progres']); ?>%</div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </ul>
                <!-- /.widget-user-list -->
            </div>
            <!-- /.widget-body -->
        </div>
        <!-- /.widget-bg -->
    </div>
</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/admin/track/track-divisi.blade.php ENDPATH**/ ?>