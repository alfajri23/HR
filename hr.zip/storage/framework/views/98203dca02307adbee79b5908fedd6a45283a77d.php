<?php $__env->startSection('sidebar'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('user|user_manager')): ?>
        <?php echo $__env->make('includes.sidebar.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <?php echo $__env->make('includes.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <div class="container-fluid d-flex">
            <!-- User Summary -->
            <div class="col-12 col-md-4 widget-holder">
                <div class="widget-bg">
                    <div class="widget-body clearfix">
                        
                        
                        <div class="contact-info">
                            <header class="text-center">
                                
                                <!-- /.dropdown -->
                                <div class="text-center">
                                   
                                    <img class="" style="width: 90%; object-fit: cover;" src="<?php echo e(asset($data->foto)); ?>" alt="">
                                    
                                </div>
                                <h4 class="mt-1"><a href="#"><?php echo e($data->nama); ?></a> <span class="badge text-uppercase badge-warning align-middle">Pro</span></h4>
                                <div class="contact-info-address"><i class="fas fa-map"></i>
                                    <p><?php echo e($data->divisi->nama); ?></p>
                                </div>
                            </header>
                            
                            <?php
                                $done = 0;
                                $progres_tot = 0;
                                foreach ($track as $tr){
                                    $progres_tot += $tr->progres; 
                                }

                                if(count($track) == 0){
                                    $progres_tot = 0;
                                }else{
                                    $progres_tot = round($progres_tot);
                                }
                                   
         
                            ?>

                            <section class="padded-reverse">
                                <h5>Detail <small class="float-right">Divisi: <strong><?php echo e($data->divisi->nama); ?></strong></small></h5>
                                <div class="row text-center">
                                    <div class="col-4"><span><?php echo e(count($track)); ?></span>
                                        <br><small>Key Result</small>
                                    </div>
                                    <div class="col-4"><span><?php echo e($progres_tot); ?>%</span>
                                        <br><small>Progress</small>
                                    </div>
                                    <div class="col-4"><span><?php echo e($done); ?></span>
                                        <br><small>Selesai</small>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <!--Contact-End -->

                    </div>
                    <!-- /.widget-body -->
                </div>
                <!-- /.widget-bg -->
            </div>


           
            <div class="col-12 col-md-8 widget-holder">
                <div class="widget-bg">
                    <div class="widget-body clearfix">
                        <div class="tabs mr-t-10">
                            <ul class="nav nav-tabs">
                                <li class="nav-item"><a href="#profile-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">Profile</a>
                                </li>
                                <li class="nav-item"><a href="#edit-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">Edit</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <!-- Detail -->
                                <div class="tab-pane active" id="profile-tab-bordered-1">
                                    <div class="contact-details-profile pd-lr-30">
                                        <h4>Profile</h4>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Nama</h6>
                                                <p class="mr-t-0"><?php echo e($data->nama); ?></p>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Username</h6>
                                                <p class="mr-t-0"><?php echo e($data->username); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Jenis kelamin</h6>
                                                <p class="mr-t-0"><?php echo e($data->jenkel); ?></p>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Alamat</h6>
                                                <p class="mr-t-0"><?php echo e($data->alamat); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Alamat KTP</h6>
                                                <p class="mr-t-0"><?php echo e($data->alamat_ktp); ?></p>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Telepon</h6>
                                                <p class="mr-t-0"><?php echo e($data->telepon); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Telepon WA</h6>
                                                <p class="mr-t-0"><?php echo e($data->telepon_wa); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Tempat lahir</h6>
                                                <p class="mr-t-0"><?php echo e($data->tmpt_lahir); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Tanggal lahir</h6>
                                                <p class="mr-t-0"><?php echo e($data->tgl_lahir); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Usia</h6>
                                                <p class="mr-t-0"><?php echo e($data->usia); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">status_keluarga</h6>
                                                <p class="mr-t-0">
                                                    <?php switch($data->status_keluarga):
                                                        case (1): ?>
                                                            Menikah
                                                            <?php break; ?>
                                                        <?php case (2): ?>
                                                            Belum menikah
                                                            <?php break; ?>
                                                        
                                                        <?php default: ?>
                                                    <?php endswitch; ?>
                                            </div>
                                        
                                        <hr class="mr-tb-50">

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Sekolah</h6>
                                                <p class="mr-t-0"><?php echo e($data->sekolah); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Pendidikan</h6>
                                                <p class="mr-t-0"><?php echo e($data->pendidikan); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Jurusan</h6>
                                                <p class="mr-t-0"><?php echo e($data->jurusan); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Rekening</h6>
                                                <p class="mr-t-0"><?php echo e($data->rekening); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Npwp</h6>
                                                <p class="mr-t-0"><?php echo e($data->npwp); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Bpjs tenaga kerja</h6>
                                                <p class="mr-t-0"><?php echo e($data->bpjs_tk); ?></p>
                                            </div>

                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Bpjs kesehatan</h6>
                                                <p class="mr-t-0"><?php echo e($data->bpjs_kes); ?></p>
                                            </div>

                                        </div>
                                        
                                        <hr class="mr-tb-50">

                                        <h4>Informasi</h4>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Pangkat</h6>
                                                <p class="mr-t-0">
                                                    <?php switch($data->pangkat):
                                                        case (1): ?>
                                                            Direktur
                                                            <?php break; ?>
                                                        <?php case (2): ?>
                                                            Manager
                                                            <?php break; ?>
                                                        <?php case (3): ?>
                                                            Supervisor
                                                            <?php break; ?>
                                                        <?php case (4): ?>
                                                            Officer
                                                            <?php break; ?>
                                                    
                                                        <?php default: ?>
                                                        
                                                    <?php endswitch; ?>
                                                    
                                                </p>
                                            </div>
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Level</h6>
                                                <p class="mr-t-0"><?php echo e($data->level); ?>

                                                    
                                                </p>
                                            </div>
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Divisi</h6>
                                                <p class="mr-t-0">
                                                    <?php switch($data->id_divisi):
                                                        case (1): ?>
                                                            HR
                                                            <?php break; ?>
                                                        <?php case (2): ?>
                                                            Budimark
                                                            <?php break; ?>
                                                        <?php case (3): ?>
                                                            MySch
                                                            <?php break; ?>
                                                        <?php case (4): ?>
                                                            Makin mahir
                                                            <?php break; ?>
                                                        <?php case (5): ?>
                                                            Dev
                                                            <?php break; ?>
                                                        <?php default: ?>
                                                    <?php endswitch; ?>
                                                
                                                    
                                                </p>
                                            </div>
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Jabatan</h6>
                                                <p class="mr-t-0"><?php echo e($data->jabatan); ?></p>
                                            </div>
                                            <div class="col-md-6">
                                                <h6 class="text-muted text-uppercase">Status kerja</h6>
                                                <p class="mr-t-0">
                                                    <?php switch($data->status_kerja):
                                                        case (1): ?>
                                                            Karyawan tetap
                                                            <?php break; ?>
                                                        <?php case (2): ?>
                                                            Karyawan tidak tetap
                                                            <?php break; ?>
                                                        <?php case (3): ?>
                                                            Karyawan kontrak
                                                            <?php break; ?>
                                                        <?php case (4): ?>
                                                            Karyawan freelancer
                                                            <?php break; ?>
                                                        <?php case (5): ?>
                                                            Training
                                                            <?php break; ?>
                                                        <?php case (6): ?>
                                                            Magang
                                                            <?php break; ?>
                                                        <?php default: ?>
                                                    <?php endswitch; ?>
                                                </p>
                                            </div>
                                            
                                        </div>
                                        <hr class="border-0 mr-tb-50">
                                    </div>
                                </div>
                                <!-- End Detail -->

                                <!-- Edit -->
                                <div class="tab-pane" id="edit-tab-bordered-1">
                                    <form class="form-material pt-3" action="<?php echo e(route('karyawanUpdate')); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="media align-items-center p-3 mb-4 bg-light-grey">
                                            <div class="d-flex mr-4 w-25 justify-content-end">
                                                <figure class="mb-0 thumb-md">
                                                    <img src="<?php echo e(asset($data->foto)); ?>" class="img-thumbnail">
                                                </figure>
                                            </div>
                                            <!-- /.d-flex -->
                                            <div class="media-body w-75">
                                                <div class="form-group">
                                                    <input type="file" class="form-control" name="file" id="logo">
                                                    <label for="exampleInputFile">File input</label>
                                                </div>
                                            </div>
                                            <!-- /.media-body -->
                                        </div>
                                        <!-- /.media -->

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="hidden" class="form-control" value="<?php echo e($data->id); ?>" name="id" id="id" aria-describedby="emailHelp">
                                                    <input type="text" class="form-control" value="<?php echo e($data->nama); ?>" name="nama" id="nama" aria-describedby="emailHelp">
                                                    <label>Nama</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="password" class="form-control" name="password" id="nama" aria-describedby="emailHelp">
                                                    <label>Password</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->username); ?>" name="username" id="usernama" aria-describedby="emailHelp" readonly>
                                                    <label>Username</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="number" class="form-control" value="<?php echo e($data->nik); ?>" name="nik" id="usernama" aria-describedby="emailHelp">
                                                    <label>NIK</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->alamat); ?>" name="alamat" id="usernama" aria-describedby="emailHelp">
                                                    <label>Alamat</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->alamat_ktp); ?>" name="alamat_ktp" id="usernama" aria-describedby="emailHelp">
                                                    <label>Alamat KTP</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->tmpt_lahir); ?>" name="tmpt_lahir" id="email">
                                                    <label for="example-email">Tempat lahir</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input onfocus="(this.type='date')" type="text" name="tgl_lahir" value="<?php echo e($data->tgl_lahir); ?>" class="form-control form-control-line">
                                                    <label>Tanggal lahir</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" placeholder="BCA 123 456 7890" name="rekening" value="<?php echo e($data->rekening); ?>" class="form-control form-control-line">
                                                    <label>Rekening</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="email" class="form-control" value="<?php echo e($data->email); ?>" name="email" id="email">
                                                    <label for="example-email">Email</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="number" placeholder="123 456 7890" name="telepon_wa" value="<?php echo e($data->telepon_wa); ?>" class="form-control form-control-line">
                                                    <label>Telepon WA</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="number" placeholder="123 456 7890" name="telepon" value="<?php echo e($data->telepon); ?>" class="form-control form-control-line">
                                                    <label>Telepon</label>
                                                </div>
                                            </div>
                                        </div>


                                        
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->pendidikan); ?>" name="pendidikan" id="email">
                                                    <label for="example-email">Pendidikan</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" name="sekolah" value="<?php echo e($data->sekolah); ?>" class="form-control form-control-line">
                                                    <label>Sekolah</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->jurusan); ?>" name="jurusan" id="email">
                                                    <label for="example-email">Jurusan</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <select id="keluarga" class="form-control" value="<?php echo e($data->status_keluarga); ?>" name="status_keluarga">
                                                        <option value="<?php echo e($data->status_keluarga); ?>">Pilih</option>
                                                        <option value="1">Menikah</option>
                                                        <option value="2">Belum menikah</option>
                                                    </select>
                                                    <label for="keluarga">Status keluarga</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                <select id="jk" class="form-control" value="<?php echo e($data->jenkel); ?>" name="jenkel">
                                                    <option value="<?php echo e($data->jenkel); ?>">Pilih</option>
                                                    <option value="1">Laki-laki</option>
                                                    <option value="2">Perempuan</option>
                                                </select>
                                                <label for="jk">Jenis kelamin</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="number" class="form-control" value="<?php echo e($data->usia); ?>" name="usia" id="email">
                                                    <label for="example-email">Usia</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->npwp); ?>" name="npwp" id="email">
                                                    <label for="example-email">NPWP</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" name="bpjs_kes" value="<?php echo e($data->bpjs_kes); ?>" class="form-control form-control-line">
                                                    <label>BPJS Kes</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" value="<?php echo e($data->bpjs_tk); ?>" name="bpjs_tk" id="email">
                                                    <label for="example-email">BPJS TK</label>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <input type="text" class="form-control" value="<?php echo e($data->jabatan); ?>" name="jabatan" id="usernama" aria-describedby="emailHelp">
                                            <label>Jabatan</label>
                                        </div>
                                        
                                        <div class="row">  
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <select class="form-control" name="status_kerja" value="<?php echo e($data->status_kerja); ?>">
                                                        <option value="<?php echo e($data->status_kerja); ?>">Pilih</option>
                                                        <option value="1">Karyawan tetap</option>
                                                        <option value="2">Karyawan tidak tetap</option>
                                                        <option value="3">Karyawan kontrak</option>
                                                        <option value="4">Karyawan freelancer</option>
                                                        <option value="5">Training</option>
                                                        <option value="6">Magang</option>
                                                    </select>
                                                    <label for="l38">Status kerja</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <select class="form-control" name="pangkat" value="<?php echo e($data->pangkat); ?>">
                                                        <option value="<?php echo e($data->pangkat); ?>">Pilih</option>
                                                        <option value="1">Direktur</option>
                                                        <option value="2">Manager</option>
                                                        <option value="3">Supervisor</option>
                                                        <option value="4">Officer</option>
                                                    </select>
                                                    <label for="l38">Pangkat</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input onfocus="(this.type='date')" type="text" class="form-control" value="<?php echo e($data->tgl_masuk_grup); ?>" name="tgl_masuk_grup" id="email">
                                                    <label for="example-email">Tanggal masuk grup</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input onfocus="(this.type='date')" type="text" name="tgl_masuk" value="<?php echo e($data->tgl_masuk); ?>" class="form-control form-control-line">
                                                    <label>Tanggal masuk</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <select class="form-control" name="id_divisi" id="l13">
                                                        <option value="<?php echo e($data->id_divisi); ?>">Pilih</option>
                                                        <?php $__currentLoopData = $divisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($us['id']); ?>"><?php echo e($us['nama']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <label for="l38">Divisi</label>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <select class="form-control" name="level" id="l13">
                                                        <option value="<?php echo e($data->level); ?>">Pilih</option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                    </select>
                                                    <label for="l38">Level</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <select class="form-control" value="<?php echo e($data->edukasi_pekanan); ?>" name="edukasi_pekanan">
                                                        <option value="<?php echo e($data->edukasi_pekanan); ?>">Pilih</option>
                                                        <option value="1">Aktif</option>
                                                        <option value="2">Tidak aktif</option>
                                                    </select>
                                                    <label for="l38">Edukasi pekanan</label>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        

                                        <div class="form-group">
                                            <button class="btn btn-success ripple">Update Profile</button>
                                        </div>
                                    </form>
                                </div>
                                <!-- End Edit -->
                            </div>
                            <!-- End tab-content -->
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            <!-- End col-12 -->
            
        </div>
        



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/user/detail.blade.php ENDPATH**/ ?>