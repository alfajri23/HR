

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.sidebar.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .bl{
        border-left: 1px solid #e8e8e8
    }

    .photo{
        object-fit: cover;
        width: 100px !important;
        height: 100px !important;
    }
</style>
        <div class="container-fluid d-flex">
            <?php
                $done = 0;
                $progres_tot = 0;
                foreach ($track as $tr){
                    //dd($tr);
                
                    $progres = 0;
                    $target = $tr->target;
                    $bobot = $tr->bobot;
                    $week = explode(",",$tr->week_1);
                    //dd($week);
                    foreach ($track as $tr){
                    $progres_tot += $tr->progres; 
                }

                if(count($track) == 0){
                    $progres_tot = 0;
                }else{
                    $progres_tot = round($progres_tot);
                }
                }

                if(count($track) == 0){
                    $progres_tot = 0;
                }else{
                    $progres_tot = $progres_tot/count($track);
                    $progres_tot = round($progres_tot);
                }
                    

            ?>

            <div class="col-12 col-md-12 widget-holder">
                <div class="widget-bg">
                    <ul class="list-unstyled widget-user-list card-body">
                        <li class="media">
                            <div class="d-flex mr-3">
                                <a class="user--online thumb-xs" style="width:70px;">
                                    <img src="<?php echo e(asset($data->foto)); ?>" class="photo" alt="">
                                </a>
                            </div>
                            <div class="media-body d-flex justify-content-between">        
                                <h5 class="media-heading">
                                    <a href="#"><?php echo e($data->nama); ?></a> 
                                    <small><?php echo e($data->username); ?></small>
                                    <small><?php echo e($data->divisi->nama); ?></small>
                                </h5>
                                <span class="btn-group mr-b-20">
                                    <button type="button" class="btn btn-outline-<?php echo e($jam > 0 ? 'danger' : 'default'); ?> ripple">
                                        <p class="mb-0">
                                            <?php if($jam < 0): ?>
                                                <?php echo e($jam*-1); ?> jam
                                        </p>
                                        <p class="mb-0">Lebih</p>
                                            <?php else: ?>
                                                <?php echo e($jam); ?>

                                        </p>
                                        <p class="mb-0">Hutang jam</p>
                                            <?php endif; ?>

                                    </button>
                                    <button type="button" class="btn btn-outline-default ripple">
                                        <p class="mb-0"><?php echo e(count($track)); ?></p>
                                        <p class="mb-0">Key result</p>
                                    </button>
                                    <button type="button" class="btn btn-outline-default ripple">
                                        <p class="mb-0"><?php echo e(round($progres_tot)); ?>%</p>
                                        <p class="mb-0">Progres</p>
                                    </button>
                                    <button type="button" class="btn btn-outline-default ripple">
                                        <p class="mb-0"><?php echo e($done); ?></p>
                                        <p class="mb-0">Done</p>
                                    </button>
                                </span>
                            </div>
                        </li>
                    </ul>
                    
                    <div class="widget-body clearfix">
                        <div class="tabs mr-t-10">
                            <ul class="nav nav-tabs">
                                <li class="nav-item"><a href="#home-tab-bordered-1" class="nav-link active" data-toggle="tab" aria-expanded="true">Activity</a>
                                </li>
                                <li class="nav-item"><a href="#okr-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">OKR</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <!-- Progress -->
                                <div class="tab-pane active" id="home-tab-bordered-1">
                                    <div class="container bg-white p-3">
                                        <h5>OKR Berjalan</h5>
                                        <?php $__empty_1 = true; $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e => $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <h4><?php echo e($e); ?></h4>
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 2px">No</th>
                                                    <th>Kode</th>
                                                    <th>Key result</th>
                                                    <th>Bobot</th>
                                                    <th>Target</th>
                                                    <th>Start</th>
                                                    <th>Pekan 1</th>
                                                    <th>Pekan 2</th>
                                                    <th>Pekan 3</th>
                                                    <th>Pekan 4</th>
                                                    <th>Pekan 5</th>
                                                    <th>Progres</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $tot_progres = 0;
                                                ?>
                                                <?php $__currentLoopData = $track; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($tr->kode_key); ?></td>
                                                    <td><?php echo e($tr->keyResult->nama); ?></td>
                                                    <td><?php echo e($tr->bobot); ?></td>
                                                    <td><?php echo e($tr->target); ?></td>
                                                    <td><?php echo e($tr->start); ?></td>
                                                    <?php
                                                        if($tr->week_1 != null){
                                                            $week = explode(",",$tr->week_1);
                                                        }else {
                                                            $week = [];
                                                        }  
                                                    ?>
                                                    
                                                    <?php for($i = 0; $i < 5; $i++): ?>
                                                        <?php if(empty($week[$i])): ?>
                                                        <td>
                                                            
                                                        </td>
                                                        <?php else: ?>
                                                        <td><?php echo e($week[$i]); ?></td>
                                                        <?php endif; ?>
                                                        
                                                    <?php endfor; ?>
                                                    <td>
                                                        <p class="my-0"><?php echo e($tr->progres); ?>%</p>
                                                        <div class="progress" data-toggle="tooltip" title="<?php echo e($tr->progres); ?>%">
                                                            <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tr->progres); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tr->progres); ?>%"><span class="sr-only"><?php echo e($tr->progres); ?>%</span>
                                                            </div>
                                                        </div>
                                                        </td>
                                                    
                                                </tr>
                                                <?php
                                                    
                                                    $tot_progres += $tr->progres;
                                                ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td colspan="11" class="text-center">Total progres</td>
                                                    <td>
                                                        <p class="my-0"><?php echo e($tot_progres); ?>%</p>
                                                        <div class="progress" data-toggle="tooltip" title="<?php echo e($tot_progres); ?>%">
                                                            <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tot_progres); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tot_progres); ?>%"><span class="sr-only"><?php echo e($tot_progres); ?>%</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td colspan="1"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>    

                                        <?php endif; ?>

                                        <?php if(!empty($multi)): ?>
                                            <h4>Total</h4>
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th style="width: 2px">No</th>
                                                        <th>Kode</th>
                                                        <th style="width: 300px;">Key result</th>
                                                        <th>Bobot</th>
                                                        <th>Target</th>
                                                        <th>Start</th>
                                                        <th>Pekan 1</th>
                                                        <th>Pekan 2</th>
                                                        <th>Pekan 3</th>
                                                        <th>Pekan 4</th>
                                                        <th>Pekan 5</th>
                                                        <th>Progres</th>
                                                        <th>Aksi</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        $tot_progres = 0;
                                                    ?>
                                                    <?php $__currentLoopData = $multi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($tr['kode_key']); ?></td>
                                                        <td><?php echo e($tr['nama']); ?></td>
                                                        <td>10%</td>
                                                        <td>100%</td>
                                                        <td>0</td>
                                                        <?php for($i = 0; $i < count($tr['data_pekan']); $i++): ?>
                                                            <?php if(empty($tr['data_pekan'][$i])): ?>
                                                            <td>
                                                                
                                                            </td>
                                                            <?php else: ?>
                                                            <td><?php echo e(number_format($tr['data_pekan'][$i])); ?></td>
                                                            <?php endif; ?>
                                                            
                                                        <?php endfor; ?>
                                                        <td>
                                                            <p class="my-0"><?php echo e($tr['progres']); ?>%</p>
                                                            <div class="progress" data-toggle="tooltip" title="<?php echo e($tr['progres']); ?>%">
                                                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tr['progres']); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tr['progres']); ?>%"><span class="sr-only"><?php echo e($tr['progres']); ?>%</span>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <?php
                                                    
                                                            $tot_progres += $tr['progres'];
                                                        ?>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td colspan="11" class="text-center">Total progres</td>
                                                        <td>
                                                            <p class="my-0"><?php echo e($tot_progres); ?>%</p>
                                                            <div class="progress" data-toggle="tooltip" title="<?php echo e($tot_progres); ?>%">
                                                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tot_progres); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tot_progres); ?>%"><span class="sr-only"><?php echo e($tot_progres); ?>%</span>
                                                                </div>
                                                            </div></td>
                                                        <td colspan="2"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        <?php endif; ?>

                                    </div>
                                    <div class="container bg-light p-3">
                                        <h5>OKR Tracking</h5>
                                        <canvas id="myChart"></canvas>
                                    </div>
                                </div>
                                <!-- End Progress -->

                                
                                <div class="tab-pane" id="okr-tab-bordered-1">
                                    <h4>OKR</h4>
                                    <div class="row">
                                        <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="col-sm-3 mr-b-20" href="<?php echo e(route('trackUser',['id' =>$data->id, 'm' => $loop->iteration])); ?>">
                                            
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title"><?php echo e($bln); ?></h5>
                                                    </div>
                                                </div>
                                            
                                        </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                          
                            </div>
                            <!-- End tab-content -->
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            <!-- End col-12 -->
            
        </div>
        


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    let datas = "<?php echo e($track_tahun); ?>";

    const labels = [
        'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    ];

    const data = {
        labels: labels,
        datasets: [{
            label: 'Progres',
            backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 132)',
            data: datas.split(","),
        }]
    };

    const config = {
        type: 'line',
        data: data,
        options: {
            scales: {
                y: {
                    suggestedMin: 0,
                    suggestedMax: 100
                },
            }
        }
    };

    const myChart = new Chart(
        document.getElementById('myChart'),
        config
    );



</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/user/karyawan-detail.blade.php ENDPATH**/ ?>