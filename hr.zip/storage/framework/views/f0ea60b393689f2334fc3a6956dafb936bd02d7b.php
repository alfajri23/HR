<?php $__env->startSection('sidebar'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
    <?php echo $__env->make('includes.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasAnyRole('user|user_manager')): ?>
    <?php echo $__env->make('includes.sidebar.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style>
    .rounded-circle{
            object-fit: cover;
            background-image: cover;
            width: 45px !important;
            height:45px !important;
    }
</style>

    <div class="row flex-wrap">
        
        <div class="col-md-12 widget-holder widget-full-height">
            <div class="widget-bg">
                <div class="widget-body clearfix">
                    <h5 class="box-title">Ranking OKR Divisi Pekan Ini</h5>
                    <ul class="list-unstyled widget-user-list mb-0">
                        <?php $__currentLoopData = $divisi_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="media">
                            <div class="d-flex mr-3">
                                <h5 class="mr-2"><?php echo e($loop->iteration); ?></h5>
                                <a href="#" class="user--online thumb-xs">
                                    <img src="<?php echo e(asset($dt['divisi']->logo)); ?>" class="rounded-circle" alt="">
                                </a>
                            </div>
                            <div class="media-body d-flex justify-content-between">
                                
                                <h5 class="media-heading"><a href="<?php echo e(route('trackDivisi',$dt['divisi']->id)); ?>"><?php echo e($dt['divisi']->nama); ?></a> <small><?php echo e($dt['divisi']->nama); ?></small></h5>
                                <div class="clearfix" style="width: 60%">
                                    <div class="progress progress-md">
                                        <div class="progress-bar bg-<?php echo e(($dt['progres'] >= 70) ? "success" : (($dt['progres'] < 70 && $dt['progres'] >= 40)  ? "warning" : "danger")); ?>" style="width: <?php echo e($dt['progres']); ?>%" role="progressbar"><?php echo e($dt['progres']); ?>%</div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-12 widget-holder widget-full-height">
            <div class="widget-bg">
                <div class="widget-body clearfix">
                    <div class="d-flex justify-content-between">
                        <h5 class="box-title">Ranking </h5>
                        <h6><i class="fas fa-info-circle" style="color: #51d2b7"></i>
                            <a href="<?php echo e(route('dashboardDetail',date('m'))); ?>">Detail</a>
                        </h6>
                    </div>
                    
                    <ul class="list-unstyled widget-user-list mb-0">
                        <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="media">
                            <div class="d-flex mr-3">
                                <h5 class="mr-2"><?php echo e($loop->iteration); ?></h5>
                                <a href="#" class="user--online thumb-xs">
                                    <img src="<?php echo e(asset($dt['user']->foto)); ?>"  style="object-fit: cover;" class="rounded-circle" alt="">
                                </a>
                            </div>
                            <div class="media-body d-flex justify-content-between">
                                
                                <h5 class="media-heading">
                                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                        <a href="<?php echo e(route('karyawanDetail',$dt['user']->id)); ?>"><?php echo e($dt['user']->nama); ?></a> 
                                        <?php endif; ?>
                                        <?php if(auth()->check() && auth()->user()->hasAnyRole('user|user_manager')): ?>
                                        <a><?php echo e($dt['user']->nama); ?></a> 
                                        <?php endif; ?>
                                    <small> 
                                        <a><?php echo e($dt['user']->jabatan); ?></a> <br>
                                        <?php switch($dt['user']->divisi->id):
                                            case (1): ?>
                                                <i style="color:rgb(166, 173, 68)" class="fas fa-male fa-lg mr-1"></i>
                                                <?php break; ?>
                                            <?php case (2): ?>
                                                <img style="width: 20px" src="https://img.icons8.com/external-dreamstale-lineal-dreamstale/32/000000/external-owl-animals-dreamstale-lineal-dreamstale-1.png"/>
                                                <?php break; ?>
                                            <?php case (3): ?>
                                                <i style="color:rgb(81, 165, 165)" class="fas fa-graduation-cap fa-lg mr-1"></i>
                                                <?php break; ?>
                                            <?php case (4): ?>
                                                <i style="color:rgb(49, 113, 233)" class="fab fa-monero fa-lg mr-1"></i>
                                                <?php break; ?>
                                            <?php case (5): ?>
                                                <i style="color:rgb(218, 94, 207)" class="fab fa-dev fa-lg mr-1"></i>
                                                <?php break; ?>
                                            <?php default: ?>
                                        <?php endswitch; ?>
                                        
                                        <?php echo e($dt['user']->divisi->nama); ?>

                                    </small>
                                </h5>

                                <div class="d-flex align-items-center" style="width:60%">
                                        
                                        
                                    <div class="progress progress-md" style="width: 100%">
                                        <div class="progress-bar bg-<?php echo e(($dt['hasil'] >= 70) ? "success" : (($dt['hasil'] < 70 && $dt['hasil'] >= 40)  ? "warning" : "danger")); ?>" style="width: <?php echo e($dt['hasil']); ?>%" role="progressbar"><?php echo e($dt['hasil']); ?>%</div>
                                    </div>
                                </div>
                            </div>
                            
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>

        
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/admin/dashboard.blade.php ENDPATH**/ ?>