<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
</head>

<style>
    .login-clean {
    background:#f1f7fc;
    padding:80px 0;
    }

    .login-clean form {
    max-width:420px;
    width:90%;
    margin:0 auto;
    background-color:#ffffff;
    padding:40px;
    border-radius:4px;
    color:#505e6c;
    box-shadow:1px 1px 5px rgba(0,0,0,0.1);
    }

    .login-clean .illustration {
    text-align:center;
    padding:0 0 20px;
    font-size:100px;
    color:rgb(244,71,107);
    }

    .login-clean form .form-control {
    background:#f7f9fc;
    border:none;
    border-bottom:1px solid #dfe7f1;
    border-radius:0;
    box-shadow:none;
    outline:none;
    color:inherit;
    text-indent:8px;
    height:42px;
    }

    .login-clean form .btn-primary {
    background:#f4476b;
    border:none;
    border-radius:4px;
    padding:11px;
    box-shadow:none;
    margin-top:26px;
    text-shadow:none;
    outline:none !important;
    }

    .login-clean form .btn-primary:hover, .login-clean form .btn-primary:active {
    background:#eb3b60;
    }

    .login-clean form .btn-primary:active {
    transform:translateY(1px);
    }

    .login-clean form .forgot {
    display:block;
    text-align:center;
    font-size:12px;
    color:#6f7a85;
    opacity:0.9;
    text-decoration:none;
    }

    .login-clean form .forgot:hover, .login-clean form .forgot:active {
    opacity:1;
    text-decoration:none;
    }


</style>

<body>
    <div class="login-clean" style="height: 100vh">
        
        <form method="post" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <h2 class="sr-only">Login Form</h2>
            <div class="illustration"><i class="icon ion-ios-navigate"></i></div>
            <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>
                    <div class="form-group">
                        <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-primary btn-block">Home</a>
                    </div>
                <?php else: ?>
                    <div class="form-group">
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-block">Log in</a>
                    </div>

                    <?php if(Route::has('register')): ?>
                        <div class="form-group">
                            <a href="<?php echo e(route('register')); ?>" class="btn btn-primary btn-block">Register</a>
                        </div>
                    <?php endif; ?>  
                <?php endif; ?>
            <?php endif; ?>
            
        </form>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH /home/bumitekno/public_html/hr/resources/views/welcome.blade.php ENDPATH**/ ?>