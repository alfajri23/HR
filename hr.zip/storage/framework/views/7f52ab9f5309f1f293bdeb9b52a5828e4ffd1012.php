<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .widget-bg{
        border-radius: 10px;
        border: 0.5px solid grey !important;
    }
</style>
<div class="widget-bg-transparent">

    
    

    <div class="container bg-white p-3">
        <h4 class="text-uppercase"><?php echo e($data->nama); ?></h4>
                        <p><?php echo e($data->deskripsi); ?></p>
        <div class="tabs mr-t-10">
            <ul class="nav nav-tabs">
                <li class="nav-item"><a href="#home-tab-bordered-1" class="nav-link active" data-toggle="tab" aria-expanded="true">OKR</a>
                </li>
                <li class="nav-item"><a href="#okr-tab-bordered-1" class="nav-link" data-toggle="tab" aria-expanded="true">Anggota</a>
                </li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" id="home-tab-bordered-1">
                    <div class="container">
                        <a href="#" data-toggle="modal" data-target="#modalObj"
                                                    class="ml-4 mb-3 btn btn-success">Tambah OKR</a>
                        <div class="container-fluid d-flex flex-wrap" id="main-obj">
                            <?php $__currentLoopData = $obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-12 col-md-12 widget-holder" id="obj-<?php echo e($bj->kode); ?>">
                                <div class="widget-bg">
                                    <div class="widget-body">
                                        <div class="d-flex justify-content-between">
                                            <h5 class="box-title" style="
                                                width: 70%;
                                                line-height: 20px;
                                            ">
                                                <?php echo e($bj->kode); ?> <?php echo e($bj->nama); ?>

                                            </h5>
                                            <span>
                                                
                                                <a href="javascript:void(0)" onclick="keyModalCreate(<?php echo e($bj->id); ?>)" class="btn btn-info btn-sm"><i class="fas fa-plus"></i></i></a>
                                                <a href="javascript:void(0)" onclick="objModalEdit(<?php echo e($bj->id); ?>)" class="btn btn-success btn-sm"><i class="fas fa-pencil-alt"></i></a>
                                                <a href="<?php echo e(route('objDelete',$bj->id)); ?>" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></a>
                                            </span>
                                        </div>
                                        
                                        <div class="todo-widget">
                                            <ol class="pl-5">
                                                <?php $__currentLoopData = $bj->keyResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li style="list-style-type:number;" class="my-1" data-checked="true">
                                                    <span class="d-flex justify-content-betweend-flex justify-content-between align-items-center">
                                                        <p class="mb-0" style="width: 90%"><strong><?php echo e($key->kode); ?></strong> <?php echo e($key->nama); ?></p> 
                                                        <span>
                                                            <a href="javascript:void(0)" onclick="keyModalEdit(<?php echo e($key->id); ?>)"><i class="fas fa-pencil-alt"></i></a>
                                                            <a href="javascript:void(0)" onclick="deleteKey(<?php echo e($key->id); ?>)"><i class="fas fa-trash-alt"></i></a>
                                                        </span>
                                                    </span>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                            </ol>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="okr-tab-bordered-1">
                    <div class="widget-body clearfix p-3">
                        <h5 class="box-title">Daftar anggota</h5>
                        <ul class="list-unstyled widget-user-list mb-0">
                            <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="media"> 
                                    <div class="d-flex mr-3">
                                        <a href="#" class="user--online thumb-xs">
                                            <img src="<?php echo e(asset($dt->foto)); ?>" class="rounded-circle" alt="">
                                        </a>
                                    </div>
                                    <div class="media-body">
                                        <h5 class="media-heading">
                                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                            <a href="<?php echo e(route('karyawanDetail',$dt->id)); ?>"><?php echo e($dt->nama); ?></a> 
                                            <?php endif; ?>
                                            <?php if(auth()->check() && auth()->user()->hasRole('user')): ?>
                                            <a><?php echo e($dt->nama); ?></a> 
                                            <?php endif; ?>
                                            <small><?php echo e($dt->username); ?></small>
                                        </h5>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <!-- /.widget-user-list -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Modal Obj-->
    <div class="modal modal-info fade bs-modal-md-primary" id="modalObj" tabindex="-1" role="dialog" aria-labelledby="myMediumModalLabel" aria-hidden="true" style="display: none">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header text-inverse">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h5 class="modal-title" id="myMediumModalLabel">Objective</h5>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('objStore')); ?>" method="POST" id="formObj">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <input type="hidden" class="form-control" name="id" id="id" aria-describedby="emailHelp">
                            <label for="exampleInputEmail1" class="form-label">Nama</label>
                            <input type="hidden" class="form-control" value="<?php echo e($data->id); ?>" name="id_divisi" id="id_divisi">
                            <input type="text" class="form-control" name="nama" id="nama" aria-describedby="emailHelp">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Kode</label>
                            <input type="text" class="form-control" name="kode" id="kode">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Deskripsi</label>
                            <input type="text" class="form-control" name="deskripsi" id="desc">
                        </div>
                        
                        
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <!--Modal Key-->
    <div class="modal modal-info fade bs-modal-md-primary" id="modalKey" tabindex="-1" role="dialog" aria-labelledby="myMediumModalLabel" aria-hidden="true" style="display: none">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header text-inverse">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h5 class="modal-title" id="myMediumModalLabel">Key</h5>
                </div>
                <div class="modal-body">
                    <form action="javascript:void(0)" id="formKey">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <input type="hidden" class="form-control" name="id" id="ids" aria-describedby="emailHelp">
                            <label for="exampleInputEmail1" class="form-label">Nama</label>
                            <input type="text" class="form-control" name="nama" id="namas" aria-describedby="emailHelp">
                        </div>

                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Kode</label>
                            <input type="text" class="form-control" name="kode" id="kodes">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Kode objecive</label>
                            <input type="text" class="form-control" name="kode_obj" id="kode_obj">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Deskripsi</label>
                            <input type="text" class="form-control" name="deskripsi" id="descs">
                        </div>
                        
                        
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
</div>

<script>
    $.ajaxSetup({
	      headers: {
	          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
	          'Authorization': `Bearer <?php echo e(Session::get('token')); ?>`
	      }
	});

    
    function objModalEdit(id){
        $.ajax({
            type : 'GET',
            url  : "<?php echo e(route('objShow')); ?>",
            data : {
                id : id
            },
            dataType: 'json',
            success : (data)=>{
                $('#modalObj').modal('show');
                $('#id').val(data.data.id);
                $('#nama').val(data.data.nama);
                $('#kode').val(data.data.kode);
                $('#desc').val(data.data.deskripsi);
            }
        });
    }

    function keyModalCreate(id){
        $.ajax({
            type : 'GET',
            url  : "<?php echo e(route('objShow')); ?>",
            data : {
                id : id
            },
            dataType: 'json',
            success : (data)=>{
                console.log(data.data);
                $('#modalKey').modal('show');
                $('#kode_obj').val(data.data.kode);
                $('#kodes').val(data.data.kode);
                $("#obj-"+id).load(" #obj-"+id);
            }
        });
    }

    function keyModalEdit(id){
        $.ajax({
            type : 'GET',
            url  : "<?php echo e(route('keyShow')); ?>",
            data : {
                id : id
            },
            dataType: 'json',
            success : (data)=>{
                console.log(data.data);
                $('#modalKey').modal('show');
                $('#kode_obj').val(data.data.kode_obj);
                $('#ids').val(data.data.id);
                $('#namas').val(data.data.nama);
                $('#kodes').val(data.data.kode);
                $('#descs').val(data.data.deskripsi);
            }
        });
    }
    
    $('#formKey').on('submit',function(){
		let data = $(this).serialize();
        console.log
        $.ajax({
            type : 'POST',
            url  : "<?php echo e(route('keyStore')); ?>",
            data : data,
            dataType: 'json',
            success : (data)=>{
                console.log(data.code.kode);
                $('#modalKey').modal('hide');
                let kot = $("#obj-"+data.code.kode);
                console.log(kot);
                $("#obj-"+data.code.kode_obj).load(window.location + " #obj-"+data.code.kode_obj+">*","");
                $('#formKey').trigger("reset");
            }
        });
    });

    $('#modalKey').on('hidden.bs.modal', function(){
        $('#formKey').trigger("reset");
    });

    $('#modalObj').on('hidden.bs.modal', function(){
        $('#formObj').trigger("reset");
    });

    function deleteKey(id){
        $.ajax({
            type : 'GET',
            url  : "<?php echo e(route('keyDelete')); ?>",
            data : {
                id : id
            },
            dataType: 'json',
            success : (data)=>{
                console.log(data);
                $("#obj-"+data.data).load(window.location + " #obj-"+data.data+">*","");
            }
        });
    }

    
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/admin/divisi/divisi-detail.blade.php ENDPATH**/ ?>