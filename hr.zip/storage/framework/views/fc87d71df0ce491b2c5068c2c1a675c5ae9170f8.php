<?php $__env->startSection('sidebar'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
    <?php echo $__env->make('includes.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('user|user_manager')): ?>
    <?php echo $__env->make('includes.sidebar.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .card:hover{
        background-color: aliceblue;
    }
</style>
<h4>Ranking</h4>
<div class="row">
    
    <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="col-sm-3 mr-b-20" href="<?php echo e(route('rankDetail',$i)); ?>">
        <div class="card">
            <div class="card-body d-flex justify-content-between" style="
                height: 100px;
            ">
                <span>
                    <h5 class="card-title"><?php echo e($bln); ?></h5>
                    
                </span>
                <span class="d-flex flex-column align-items-center">
                    
                    <?php if($i > count($top)): ?>
                    <h6></h6>
                    <?php else: ?>
                    <div href="#" class="user--online thumb-xs">
                        <img src="<?php echo e(asset($top[$i - 1]->user->foto)); ?>" class="rounded-circle" alt="">
                    </div>
                    <h6 class="mb-0 mt-1"><?php echo e($top[$i - 1]->user->nama); ?> <i class="fas fa-medal fa-lg" style="color: gold"></i></h6>
                    <?php endif; ?>
                </span>
                
            </div>
        </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/rank/rank_list.blade.php ENDPATH**/ ?>