<?php $__env->startSection('sidebar'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
    <?php echo $__env->make('includes.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('user|user_manager')): ?>
    <?php echo $__env->make('includes.sidebar.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    
    <h4><?php echo e($user->nama); ?><br><small><?php echo e($bulan); ?></small></h4>
    
    <div class="container-fluid bg-white p-3">
        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <a href="#" data-toggle="modal" data-target="#modalTrack"
                                class="mb-3 btn btn-success btn-sm">Tambah Objective </a>
        <?php endif; ?>
        <?php if($user->multi_okr != 0 ): ?>
            <a href="<?php echo e(route('subdivIndex')); ?>" class="mb-3 btn btn-info btn-sm">Tambah Subdivisi</a>
        <?php endif; ?>
        <?php $__empty_1 = true; $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e => $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>  
        

        <h4><?php echo e($e); ?></h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th style="width: 2px">No</th>
                    <th>Kode</th>
                    <th>Key result</th>
                    <th>Bobot</th>
                    <th>Target</th>
                    <th>Start</th>
                    <th>Pekan 1</th>
                    <th>Pekan 2</th>
                    <th>Pekan 3</th>
                    <th>Pekan 4</th>
                    <th>Pekan 5</th>
                    <th>Total</th>
                    <th>Progres</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $tot_progres = 0;
                    $tot_bobot = 0;
                ?>
                <?php $__currentLoopData = $track; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($tr->kode_key); ?></td>
                    <td><?php echo e($tr->keyResult->nama); ?></td>
                    <td class="text-center"><?php echo e($tr->bobot); ?></td>
                    <td class="text-center"><?php echo e($tr->target); ?></td>
                    <td class="text-center"><?php echo e($tr->start); ?></td>
                    <?php
                        if($tr->week_1 != null){
                            $week = explode(",",$tr->week_1);
                        }else {
                            $week = [];
                        }  
                    ?>
                    
                    <?php for($i = 0; $i < 5; $i++): ?>
                        <?php if(empty($week[$i])): ?>
                        <td>
                            
                        </td>
                        <?php else: ?>
                        <td  class="text-center"><?php echo e(number_format($week[$i])); ?></td>
                        <?php endif; ?>
                    <?php endfor; ?>
                    <td><?php echo e($tr->total); ?></td>
                    <td>
                        <p class="my-0"><?php echo e($tr->progres); ?>%</p>
                        
                    </td>
                    <td>
                        <a href="javascript:void(0)" onclick="okrEdit(<?php echo e($tr->id); ?>)" class="btn btn-info btn-sm"><i class="fas fa-dot-circle"></i></a>
                        <a href="javascript:void(0)" onclick="trackModalEdit(<?php echo e($tr->id); ?>)" class="btn btn-success btn-sm"><i class="fas fa-pencil-alt"></i></a>
                        <a href="<?php echo e(route('trackDelete',$tr->id)); ?>" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></a>
                    </td>
                    
                </tr>
                <?php
                    $tot_bobot += $tr->bobot;
                    $tot_progres += $tr->progres;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="3" class="text-center">Bobot</td>
                    <td colspan="1"  class="text-center"><?php echo e($tot_bobot); ?></td>
                    <td colspan="8" class="text-center">Total progres</td>
                    <td colspan="1">
                        <p class="my-0"><?php echo e($tot_progres); ?>%</p>
                        <div class="progress" data-toggle="tooltip" title="<?php echo e($tot_progres); ?>%">
                            <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tot_progres); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tot_progres); ?>%"><span class="sr-only"><?php echo e($tot_progres); ?>%</span>
                            </div>
                        </div>
                    </td>
                    <td colspan="1"></td>
                    
                </tr>
            </tbody>
        </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>    

        <?php endif; ?>

        <?php if(!empty($multi)): ?>
            <h4>Total</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width: 2px">No</th>
                        <th>Kode</th>
                        <th style="width: 300px;">Key result</th>
                        <th>Pekan 1</th>
                        <th>Pekan 2</th>
                        <th>Pekan 3</th>
                        <th>Pekan 4</th>
                        <th>Pekan 5</th>
                        <th>Progres</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $tot_progres = 0;
                    ?>
                    <?php $__currentLoopData = $multi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($tr['kode_key']); ?></td>
                        <td><?php echo e($tr['nama']); ?></td>
                        <?php for($i = 0; $i < count($tr['data_pekan']); $i++): ?>
                            <?php if(empty($tr['data_pekan'][$i])): ?>
                            <td>
                                
                            </td>
                            <?php else: ?>
                            <td class="text-center"><?php echo e(number_format($tr['data_pekan'][$i])); ?></td>
                            <?php endif; ?>
                            
                        <?php endfor; ?>
                        <td>
                            <p class="my-0"><?php echo e($tr['progres']); ?>%</p>
                            <div class="progress" data-toggle="tooltip" title="<?php echo e($tr['progres']); ?>%">
                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tr['progres']); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tr['progres']); ?>%"><span class="sr-only"><?php echo e($tr['progres']); ?>%</span>
                                </div>
                            </div>
                        </td>
                        <?php
                
                            $tot_progres += $tr['progres'];
                        ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="8" class="text-center">Total progres</td>
                        <td colspan="1">
                            <p class="my-0"><?php echo e($tot_progres); ?>%</p>
                            <div class="progress" data-toggle="tooltip" title="<?php echo e($tot_progres); ?>%">
                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($tot_progres); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($tot_progres); ?>%"><span class="sr-only"><?php echo e($tot_progres); ?>%</span>
                                </div>
                            </div></td>
                        
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>
        


        
    </div>

    <!--Modal OKR-->
    <div class="modal modal-info fade bs-modal-md-primary" id="modalTrack" tabindex="-1" role="dialog" aria-labelledby="myMediumModalLabel" aria-hidden="true" style="display: none">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header text-inverse">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h5 class="modal-title" id="myMediumModalLabel">Objective</h5>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('trackStore')); ?>" method="POST" id="formObj">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3" id="inputKey">
                            <label for="exampleInputPassword1" class="form-label">Key result</label>
                            <select class="form-control" name="key" id="key">
                                <?php $__currentLoopData = $key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ky): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ky['kode']); ?>"><?php echo e($ky['kode']); ?> <?php echo e($ky['nama']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>   
                        <?php if($user->multi_okr != 0 ): ?>
                        <div class="mb-3" id="inputKey">
                            <label for="exampleInputPassword1" class="form-label">Divisi</label>
                            <select class="form-control" name="multi" id="multi">
                                <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sub->nama); ?>"><?php echo e($sub->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>  
                        <?php endif; ?>    
                        <div class="mb-3">
                            <input type="hidden" class="form-control" name="id" id="id" aria-describedby="emailHelp">
                            
                            <input type="hidden" class="form-control" value="<?php echo e($user->id); ?>" name="id_user" id="id_user">
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlSelect1">Bulan</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="bulan" id="bulan">
                                <option value="1">Januari</option>
                                <option value="2">Februari</option>
                                <option value="3">Maret</option>
                                <option value="4">April</option>
                                <option value="5">Mei</option>
                                <option value="6">Juni</option>
                                <option value="7">Juli</option>
                                <option value="8">Agustus</option>
                                <option value="9">September</option>
                                <option value="10">Oktober</option>
                                <option value="11">November</option>
                                <option value="12">Desember</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Target</label>
                            <input type="number" class="form-control" name="target" id="target">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Bobot</label>
                            <input type="number" class="form-control" name="bobot" id="bobot">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Start</label>
                            <input type="number" class="form-control" name="start" id="start">
                        </div>
                        
                        <button type="submit" id="btnOkr" class="btn btn-primary">Tambah</button>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    
    <div class="modal modal-info fade bs-modal-md-primary" id="modalOkr" tabindex="-1" role="dialog" aria-labelledby="myMediumModalLabel" aria-hidden="true" style="display: none">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header text-inverse">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h5 class="modal-title" id="myMediumModalLabel">Edit data pekan</h5>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('trackUpdate')); ?>" method="POST" id="formObj">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Total</label>
                            <input type="number" class="form-control" name="total" id="total">
                            <input type="hidden" class="form-control" name="id" id="id_okr">
                        </div>
                        <div id="okrList"></div>
                        <button type="submit" id="btnOkr" class="btn btn-primary">Edit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<script>

    $.ajaxSetup({
	      headers: {
	          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
	          'Authorization': `Bearer <?php echo e(Session::get('token')); ?>`
	      }
	});


    $('#modalTrack').on('hidden.bs.modal', function () {
        $('#inputKey').show();
        console.log("hallo");
    });

    function show(){
        $('#inputKey').show();
    }

    function trackModalEdit(id){
        $.ajax({
            type : 'GET',
            url  : "<?php echo e(route('trackShow')); ?>",
            data : {
                id : id
            },
            dataType: 'json',
            success : (data)=>{
                console.log(data.data);
                $('#modalTrack').modal('show');
                $('#id').val(data.data.id);
                $('#target').val(data.data.target);
                $('#bobot').val(data.data.bobot);
                $('#start').val(data.data.start);
                $('#key').val(data.data.kode_key);
                $('#btnOkr').html("Edit");
                // $('#inputKey').hide();
            }
        });
    }



    function okrEdit(id){
        let inputWeek = ``;
        let input = '';

        function loop(no,index){
            input += `
            <div class="col-12 mb-3">
            <label for="exampleInputPassword1" class="form-label">Pekan ${index+1}</label>
            <input class="form-control" name="week_no[]" value="${index}" type="hidden">
            <input type="text" class="form-control" value="${no}" name="week_val[]">
            </div>
            `;
        }

        $.ajax({
            type : 'GET',
            url  : "<?php echo e(route('trackShow')); ?>",
            data : {
                id : id
            },
            dataType: 'json',
            success : (data)=>{
                console.log(data.data);
                
                $('#id_okr').val(data.data.id);
                $('#total').val(data.data.total);
                let week = data.data.week_1;
                week = week.split(',');
                week.forEach(loop);
                //console.log(input);

                $('#okrList').html(input);
                $('#modalOkr').modal('show');

                // $('#inputKey').hide();
            }
        });
    }
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bumitekno/public_html/hr/resources/views/content/admin/track/track-user.blade.php ENDPATH**/ ?>