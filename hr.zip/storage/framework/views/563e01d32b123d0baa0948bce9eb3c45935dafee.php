<aside class="site-sidebar scrollbar-enabled clearfix">
    
    <!-- Sidebar Menu -->
    <nav class="sidebar-nav">
        <ul class="nav in side-menu">
            <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-columns fa-lg mr-1"></i> </i><span class="hide-menu">Dashboard</span></a>
            </li>
            <li><a href="<?php echo e(route('rankList')); ?>"><i class="fas fa-medal fa-lg mr-2"></i></i><span class="hide-menu">Ranking</span></a>
            </li>
            <li class="menu-item-has-children"><a href="javascript:void(0);"><i class="fas fa-building fa-lg mr-3"></i>Master</a>
                <ul class="list-unstyled sub-menu collapse in ml-5">
                    <li><a href="<?php echo e(route('karyawanAdmin')); ?>"><i class="fas fa-user-friends mr-2"></i>Karyawan</a>
                    </li>
                    <li><a href="<?php echo e(route('divisiAdmin')); ?>"><i class="fas fa-building mr-3"></i></i>Divisi</a>
                    </li>
                </ul>
            </li>
            <li class="menu-item-has-children"><a href="javascript:void(0);"><i class="far fa-calendar-minus fa-lg mr-3"></i>Perizinan</a>
                <ul class="list-unstyled sub-menu collapse in ml-5">
                    <li><a href="<?php echo e(route('gantiAdmin')); ?>"><i class="fas fa-user-clock mr-2"></i></i>Ganti jam</a>
                    </li>
                    <li><a href="<?php echo e(route('izinAdmin')); ?>"><i class="fas fa-forward mr-2"></i></i>Izin</a>
                    </li>
                    <li><a href="<?php echo e(route('izinAdminSakit')); ?>"><i class="fas fa-head-side-cough mr-2"></i></i>Sakit</a>
                    </li>
                    <li><a href="<?php echo e(route('cutiAdmin')); ?>"><i class="far fa-copyright mr-2"></i></i>Cuti</a>
                    </li>
                    <li><a href="<?php echo e(route('lemburAdmin')); ?>"><i class="fas fa-laptop-house mr-2"></i></i>Lembur</a>
                    </li>
                </ul>
            </li>
            <li><a href="<?php echo e(route('ibadahList')); ?>"><i class="fas fa-pray fa-lg mr-3"></i></i><span class="hide-menu">Ibadah</span></a>
            </li>
            
            
            
            
            
        </ul>
        <!-- /.side-menu -->
    </nav>
    <!-- /.sidebar-nav -->
</aside><?php /**PATH /home/bumitekno/public_html/hr/resources/views/includes/sidebar/admin.blade.php ENDPATH**/ ?>