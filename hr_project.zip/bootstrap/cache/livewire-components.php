<?php return array (
  'karyawan' => 'App\\Http\\Livewire\\Karyawan',
  'karyawans-table' => 'App\\Http\\Livewire\\KaryawansTable',
  'tables.karyawans-table' => 'App\\Http\\Livewire\\Tables\\KaryawansTable',
);